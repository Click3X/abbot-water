<?php

// add any new or customised functions here
require_once ( "core/init-child.php" );
if(isset($_GET['menu-style']) && !empty($_GET['menu-style'])){
    $ts_ariva['menu-style'] = $_GET['menu-style'];
}
if(isset($_GET['ts-menu-autohide']) && !empty($_GET['ts-menu-autohide'])){
    $ts_ariva['ts-menu-autohide'] = $_GET['ts-menu-autohide'];
}