<div class="group-share pull-right">
    <span><?php echo __('Share on :', 'themestudio'); ?></span>
	<a target="_blank" href="https://twitter.com/home?status=<?php the_permalink(); ?>">Twitter</a>/
  	<a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>">Facebook</a>/
  	<a target="_blank" href="https://pinterest.com/pin/create/button/?url=&media=&description=<?php the_permalink(); ?>">Pinterest</a>/
  	<a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>">Google</a>
</div>