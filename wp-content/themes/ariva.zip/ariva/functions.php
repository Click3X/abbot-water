<?php
	/*
	 * Load Framework
	*/
	require_once ( "core/init.php");